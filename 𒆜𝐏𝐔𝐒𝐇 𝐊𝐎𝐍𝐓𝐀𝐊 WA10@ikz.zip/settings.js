// NO RECODE TANPA IZIN MINIMAL KALO MAU RECODE IZIN DULU!!!
// CREATOR : KAMIKZ
// ADMIN : KAMIKZ
// RECODE BY KAMIKZ OFFCIAL JOIN SALURAN TELE KAMI DI BAWAH
// https://t.me/testiellcihuy

require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6283170966509";
global.namaowner = "𝙄𝙆𝙕/𝘿𝙄𝙆𝙕";
global.version = "v2.0.0";

//======== Setting Bot & Link ========//
global.namabot = "𝙄𝙆𝙕 𝘽𝙊𝙏𝙕" 
global.namabot2 = "𝙄𝙆𝙕 𝘽𝙊𝙏𝙕 2"
global.foother = "𝘿𝙄𝙆𝙕 "
global.idsaluran = "120363402567181052"
global.linkgc = 'https://chat.whatsapp.com/DOcHj9KJrzuIohd4KuGKWe'
global.linksaluran = "https://whatsapp.com/channel/0029Vb9pKFBJf05Y7kmcRQ0L"
global.linkyt = false
global.linktele = "t.me/kamikzoffcialid"
global.packname = "𝙄𝙆𝙕"
global.author = "𝙄𝙆𝙕"

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false 
global.owneroff = false

//==== Waktu Jeda Pushkontak ====//
global.delaypushkontak = 5500;

//==== settings panel ====//
global.egg = "15"; //isi dengan eggs lu
global.nestid = "5"; //isi dengan nest id lu
global.loc = "1"; //isi dengan location lu
global.domain = ""; //isi domain lu
global.apikey = ""; //isi dengan plta lu
global.capikey = ""; //isi dengan pltc lu

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "089643416550"
global.gopay = "083133298476"
                             
//=========== Api Domain ===========//
global.zone1 = "";
global.apitoken1 = "";
global.tld1 = ""

//========== Api Domain 2 ==========//
global.zone2 = "";
global.apitoken2 = "";
global.tld2 = "";
//========== Api Domain 3 ==========//
global.zone3 = "";
global.apitoken3 = "";
global.tld3 = "";
//========== Api Domain 4 ==========//
global.zone4 = "";
global.apitoken4 = "";
global.tld4 = "";

//========= Setting Message =========//
global.msg = {
"error": "Error terjadi kesalahan",
"done": "Done Bang ✅", 
"wait": "Please Wait..", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})